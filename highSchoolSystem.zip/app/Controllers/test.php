<?php phpinfo();
